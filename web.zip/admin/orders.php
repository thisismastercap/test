<?php
require '../config.php';

// استعلام جلب الطلبات
$stmt = $conn->query("
    SELECT o.*, 
           COUNT(i.item_id) as items_count,
           SUM(i.price * i.quantity) as subtotal
    FROM orders o
    LEFT JOIN order_items i ON o.order_id = i.order_id
    GROUP BY o.order_id
    ORDER BY o.created_at DESC
");
$orders = $stmt->fetchAll();
?>

<table>
    <thead>
        <tr>
            <th>رقم الطلب</th>
            <th>العميل</th>
            <th>الهاتف</th>
            <th>العنوان</th>
            <th>عدد المنتجات</th>
            <th>المجموع</th>
            <th>الحالة</th>
            <th>التاريخ</th>
            <th>إجراءات</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($orders as $order): ?>
        <tr>
            <td><?= $order['order_id'] ?></td>
            <td><?= htmlspecialchars($order['customer_name']) ?></td>
            <td><?= $order['customer_phone'] ?></td>
            <td><?= htmlspecialchars($order['city']) . ', ' . htmlspecialchars($order['region']) ?></td>
            <td><?= $order['items_count'] ?></td>
            <td><?= number_format($order['order_total'], 2) ?> ر.ع</td>
            <td>
                <select class="status-select" data-order-id="<?= $order['order_id'] ?>">
                    <option value="pending" <?= $order['order_status']=='pending'?'selected':'' ?>>قيد الانتظار</option>
                    <option value="processing" <?= $order['order_status']=='processing'?'selected':'' ?>>قيد المعالجة</option>
                    <option value="shipped" <?= $order['order_status']=='shipped'?'selected':'' ?>>تم الشحن</option>
                    <option value="delivered" <?= $order['order_status']=='delivered'?'selected':'' ?>>تم التسليم</option>
                    <option value="cancelled" <?= $order['order_status']=='cancelled'?'selected':'' ?>>ملغي</option>
                </select>
            </td>
            <td><?= date('Y/m/d H:i', strtotime($order['created_at'])) ?></td>
            <td>
                <a href="order_details.php?id=<?= $order['order_id'] ?>" class="btn">التفاصيل</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>