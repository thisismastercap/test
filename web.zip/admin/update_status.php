<?php
require '../config.php';

$orderId = $_POST['order_id'];
$newStatus = $_POST['status'];

try {
    $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");
    $stmt->execute([$newStatus, $orderId]);
    
    echo json_encode(['success' => true]);
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>